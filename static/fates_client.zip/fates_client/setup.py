from setuptools import setup, find_packages
setup(
    name = 'fates_client',
    packages = find_packages(),
)
