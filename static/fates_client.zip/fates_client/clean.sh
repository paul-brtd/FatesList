rm -rf build dist fates_client.egg-info/
